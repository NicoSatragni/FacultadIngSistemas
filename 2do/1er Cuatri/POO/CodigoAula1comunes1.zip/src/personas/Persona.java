package personas;

import java.awt.BorderLayout;
import java.beans.beancontext.BeanContextServiceAvailableEvent;

public class Persona {

	private String nombre;
	private int dni;
	
	private static int contadorPersonas=0;
	private static Persona primerisima = null;


	public String getNombre() {
		return nombre;
	}

	public void setNombre(String nombre) {
		this.nombre = nombre;
	}

	public int getDni() {
		return dni;
	}

	public void setDni(int dni) {
		this.dni = dni;
	}

	public Persona(String nombre) {
		super();
		this.nombre = nombre;
		contadorPersonas ++;
		this.dni = contadorPersonas;
		if (primerisima == null)
		    primerisima = this;
	}
	
	public static int getContador(){
	
		return contadorPersonas;
		
	}

	public static Persona getPrimera() {
		return primerisima;
	}
	
	
	
	public static void main(String [] args) {
		for (int i = 0 ; i<3430; i++) {
			Persona pp = new Persona("jj");
		}
		
		Persona pepe = new Persona("Ana");
		System.out.println(pepe.getDni());
		for (int i = 0 ; i<3430; i++) {
			Persona pp = new Persona("jj");
		}
	
		System.out.println(Persona.getContador());
		
		System.out.println(Persona.getPrimera().getDni());
		
		
	}
}
