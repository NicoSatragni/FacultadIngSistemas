package figuras;

import figuras.redondas.MedioCirculo;

public class Principal {

	public static void main(String[] args) {
		MedioCirculo md = new MedioCirculo(10);
		System.out.println(md.getEtiqueta());
	}

}
