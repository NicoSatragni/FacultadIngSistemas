package figuras;

public class Figura {

	private String nombre;

	public Figura(String nombre) {
		this.nombre = nombre;
	}
	
	public double getArea() {
		return 0;
	}
	
	public double getPerimetro() {
		return 0;
	}

	public String getNombre() {
		return nombre;
	}
	
	public String getEtiqueta() {
		return this.getNombre() +"(" + this.getArea() + "," + this.getPerimetro() +")";
	}
	
}
