package libreria;

public class ClienteLeGustaTodo extends Cliente {

	public ClienteLeGustaTodo(String nombre, String apellido, String direccion, int dni) {
		super(nombre, apellido, direccion, dni);
		// TODO Auto-generated constructor stub
	}
	
	public boolean leGusta(Producto pp) {
		return true;
	}

}
