package libreria;

public class ClienteExigente extends Cliente {

	public ClienteExigente(String nombre, String apellido, String direccion, int dni) {
		super(nombre, apellido, direccion, dni);
		// TODO Auto-generated constructor stub
	}

	public boolean leGusta(Producto pp) {
		boolean salida = super.leGusta(pp);
		if (salida) {
			for(int i = 0; i< generosFavoritos.size();i++) {
				if (pp.tieneGenero(generosFavoritos.get(i))) {
					return true;
				}
			}
		}
		return false;
	}
	
}
