package libreria;

import java.lang.reflect.Array;
import java.util.ArrayList;

public class Libreria {

	ArrayList<Cliente> clientes;
	
	public double getPrecio(Producto pp, Cliente cc) {
		return pp.getPrecio() - pp.getPrecio()*cc.getDescuento()/100;
	}
	
	public boolean yaCompro(Cliente cc, Producto pp) {
		return cc.comproProducto(pp);
	}
	
	public boolean leGusta(Producto pp, Cliente cc) {
		return cc.leGusta(pp);
	}
	
	public ArrayList<Cliente> clientesQueLesGusta(Producto pp){
		ArrayList<Cliente> salida = new ArrayList<Cliente>();
		for(int i =0;i < clientes.size(); i++) {
			Cliente posI = clientes.get(i);
			if (posI.leGusta(pp)) {
				salida.add(posI);
			}
		}
		return salida;
	}
}
