package libreria;

import java.util.ArrayList;

public class Producto {
	/*
	 * nombre, autor (solo uno), precio,
cantidad de páginas, un resumen y géneros literarios
que abarca (puede ser más de uno
	 */
	private String nombre;
    private String autor;
    private double precio;
    private int paginas;
    private String resumen;
    private ArrayList<String> generos;
    
    
    
    
	public Producto(String nombre, String autor, double precio, int paginas, String resumen) {
		super();
		this.nombre = nombre;
		this.autor = autor;
		this.precio = precio;
		this.paginas = paginas;
		this.resumen = resumen;
		generos= new ArrayList<String>();
	}
	public String getNombre() {
		return nombre;
	}
	public void setNombre(String nombre) {
		this.nombre = nombre;
	}
	public String getAutor() {
		return autor;
	}
	public void setAutor(String autor) {
		this.autor = autor;
	}
	public double getPrecio() {
		return precio;
	}
	public void setPrecio(double precio) {
		this.precio = precio;
	}
	public int getPaginas() {
		return paginas;
	}
	public void setPaginas(int paginas) {
		this.paginas = paginas;
	}
	public String getResumen() {
		return resumen;
	}
	public void setResumen(String resumen) {
		this.resumen = resumen;
	}
    
    
    
    public void addGenero(String genero) {
    	if (! generos.contains(genero.toUpperCase()))
    	    generos.add(genero.toUpperCase());
    	
    }
    
    public boolean tieneGenero(String genero) {
    	return generos.contains(genero.toUpperCase());
    }
    
    public void removeGenero(String genero) {
    	generos.remove(genero.toUpperCase());
    }
    
    public boolean equals(Object o1) {
      try {
    	Producto pp = (Producto) o1;
    	return autor.equalsIgnoreCase(pp.getAutor()) &&
    			paginas == pp.getPaginas() &&
    			nombre.equalsIgnoreCase(pp.getNombre());
      } catch(Exception e) {
    	  return false;
    	  
      }
    }
    
    public boolean leGustasA(Cliente cc) {
    	return cc.leGusta(this);
    }
}
