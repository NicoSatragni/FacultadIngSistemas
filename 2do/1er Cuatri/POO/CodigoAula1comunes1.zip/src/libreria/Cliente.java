package libreria;

import java.util.ArrayList;

public class Cliente {

	private String nombre, apellido, direccion;
	private int dni;
	private ArrayList<String> autoresFavoritos;
	protected ArrayList<String> generosFavoritos;
	private ArrayList<Producto> compras;
	
	private double descuento;
	
	
	





	public Cliente(String nombre, String apellido, String direccion, int dni) {
		super();
		this.nombre = nombre;
		this.apellido = apellido;
		this.direccion = direccion;
		this.dni = dni;
		autoresFavoritos = new ArrayList<String>();
		generosFavoritos  = new ArrayList<String>();
		compras = new ArrayList<Producto>();
		descuento = 10;
	}
	
	
	public double getDescuento() {
		return descuento;
	}


	public void setDescuento(double descuento) {
		this.descuento = descuento;
	}


	public String getNombre() {
		return nombre;
	}


	public void setNombre(String nombre) {
		this.nombre = nombre;
	}


	public String getApellido() {
		return apellido;
	}


	public void setApellido(String apellido) {
		this.apellido = apellido;
	}


	public String getDireccion() {
		return direccion;
	}


	public void setDireccion(String direccion) {
		this.direccion = direccion;
	}


	public int getDni() {
		return dni;
	}


	public void setDni(int dni) {
		this.dni = dni;
	}


	public ArrayList<Producto> getCompras(){
		//return new ArrayList<Producto>(compras);
		ArrayList<Producto> salida = new ArrayList<Producto>();
		for (int i =0; i< compras.size();i++) {
			salida.add(compras.get(i));
		}
		return salida;
		
		//return (ArrayList<Producto>)compras.clone();
		
		
		/*ESTO NO
		 * ArrayList<Producto> salida = compras;
		 * return compras;
		 */
	}
	
	
	 public void addGenero(String genero) {
	    	if (! generosFavoritos.contains(genero.toLowerCase()))
	    	    generosFavoritos.add(genero.toLowerCase());
	    	
	    }
	    
	    public boolean tieneGenero(String genero) {
	    	return generosFavoritos.contains(genero.toLowerCase());
	    }
	    
	    public void removeGenero(String genero) {
	    	generosFavoritos.remove(genero.toLowerCase());
	    }
	
	    public void addAutor(String autor) {
	    	if (! autoresFavoritos.contains(autor.toUpperCase()))
	    	    autoresFavoritos.add(autor.toUpperCase());
	    	
	    }
	    
	    public boolean leGustaAutor(String au) {
	    	return autoresFavoritos.contains(au.toUpperCase());
	    }
	    
	    public void removeAutor(String au) {
	    	autoresFavoritos.remove(au.toUpperCase());
	    }
	
	    
	    public void addCompra(Producto prod) {
	    	   compras.add(prod);
	    	
	    }
	    
	    public boolean comproProducto(Producto pp) {
	    	// PARA QUE FUNCION PRODUCTO DEBE IMPLEMENTAR Equals
	    	return compras.contains(pp); 
	    }
	    
	    public void removeProducto(Producto pp) {
	    	//REQUIERE EQUALS
	    	compras.remove(pp);
	    }
	    
	    public boolean leGusta(Producto pp) {
	    	return this.leGustaAutor(pp.getAutor());
	    }
}
