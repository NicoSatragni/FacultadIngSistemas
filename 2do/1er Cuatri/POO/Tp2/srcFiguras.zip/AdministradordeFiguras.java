
public class AdministradordeFiguras {

	public void imprimirFigura(Figura ff) {
		System.out.println("El "+ff.getNombre() +" tiene un area: " +
	                        ff.getArea() + " perimetro: " +
				            ff.getPerimetro());
	}
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Rectangulo r1= new Rectangulo(10, 10);
		AdministradordeFiguras admin = new AdministradordeFiguras();
		admin.imprimirFigura(r1);
		
		Circulo c1 = new Circulo(10);
		
		admin.imprimirFigura(c1);
		
		
		
		Figura ff = new Figura("Cualquiera");
		
		System.out.println(ff.getNombre());
		System.out.println(ff.getArea());
		System.out.println(ff.getPerimetro());
		
		Circulo c10 = new Circulo(10);
		
		//ff = c10;
		c10.getRadio();
		System.out.println(ff.getNombre());
		System.out.println(ff.getArea());
		System.out.println(ff.getPerimetro());
		
		//System.out.println(((Circulo)ff).getRadio());
		
		
		MedioCirculo mm = new MedioCirculo(20);
		
		admin.imprimirFigura(mm);
		

	}

}
