
public class MedioCirculo extends Circulo {

	public MedioCirculo(double rad) {
		super(rad);
	}
	
	public double getArea() {
		return super.getArea() /2;
	}
	
	public String getNombre() {
		return "Medio"+super.getNombre();
	}
	
	public double getPerimetro() {
		return super.getPerimetro()/2+this.getDiametro();
	}
}
