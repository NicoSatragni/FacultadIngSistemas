
public class Juego2 {
		private int puntos1;
		private int puntos2;
		private Dado d1;
		private Dado d2;
		
		public void jugar() {
			int tirada1, tirada2;
			
			for (int i =0 ; i<10; i++) {
				tirada1 = d1.tirar() + d2.tirar();
				tirada2 = d1.tirar() + d2.tirar();
				
				if (tirada1>tirada2 && tirada1>=7) {
					puntos1++;
				} else {
					if (tirada2>tirada1 && tirada2>=7) {
						puntos2++;
					}
   			    }
			}
			String ganador = ganador();
		    if (ganador!= null) {
		    	System.out.println("Gano el " + ganador);
		    } else {
		    	System.out.println("Empate");
		    }
		}
		
		public String ganador() {
			if (puntos1>puntos2) {
				return "Jugador 1";
			} else {
				if (puntos2>puntos1) {
	                return "Jugador 2";   
				}	
				else {
					return null; 
				}
			}
		}

		public Juego2() {
			puntos1=0;
			puntos2=0;
			d1 = new Dado();
			d2 = new Dado();
		}
		
		public Juego2(Dado d1, Dado d2) {
			puntos1=0;
			puntos2=0;
			this.d1 = d1;
			this.d2 = d2;
		}
		
		public static void main(String[] args) {
			Juego2 jj = new Juego2();
			jj.jugar();
		}
		
		
	
}
