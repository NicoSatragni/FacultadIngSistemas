
public class Cubilete {

	Dado[] dados;
	
	public Cubilete() {
		this(2,6);
	}
	public Cubilete(int cantidad, int carasDados) {
		dados = new Dado[cantidad];
		for(int i =0; i< dados.length; i++) {
			dados[i] = new Dado(carasDados);
		}
	}
	

	public Cubilete(Dado[] nuevosDados) {
		dados = nuevosDados;
	}

	public Dado[] getDados() {
		return dados;
	}

	public void setDados(Dado[] dados) {
		this.dados = dados;
	}
	
	
	public int tirar() {
		int suma = 0;
		for(int i =0; i<dados.length; i++) {
			suma = suma + dados[i].tirar();
		}
		return suma;
	}
	
	
}
