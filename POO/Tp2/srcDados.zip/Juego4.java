
public class Juego4 {
				private Jugador j1;
				private Jugador j2;
				private Cubilete vasito;
				
				private int rondas;
				private int minimo;
				
				public Juego4() {
					this(new Cubilete(2,6));
				}
				
                public Juego4(Cubilete vaso) {
                	this(vaso, new Jugador("EL 1"), new Jugador("El 2"));
                }
				
				public Juego4(Cubilete vaso, Jugador j1, Jugador j2) {
					this.j1 = j1;
					this.j2 = j2;
					vasito = vaso;
					rondas = 10;
					minimo = 7;
				}
				public void jugar() {
					int tirada1, tirada2;
					for (int i =0 ; i<rondas; i++) {
						System.out.println("RONDA: " + i);
						tirada1 = j1.tirarDados(vasito);
						tirada2 = j2.tirarDados(vasito);
						
						if (tirada1>tirada2 && tirada1>=minimo) {
							j1.sumarPunto();
						} else {
							if (tirada2>tirada1 && tirada2>=minimo) {
								j2.sumarPunto();
							}
						}
					}
					Jugador jj = this.getGanador();
					if (jj != null) {
						System.out.println("Gano : " + jj.getNombre());
					} else {
						System.out.println("Empate");
							
					}
					
						System.out.println("Jugador 1:" + j1.getPuntos());
						System.out.println("Jugador 2:" + j2.getPuntos());
					
					
				}
				
				public Jugador getGanador() {
					if (j1.getPuntos()>j2.getPuntos()) {
						return j1;
					} else {
						if (j2.getPuntos()>j1.getPuntos()) {
							return j2;
						} else {
							return null;
						}
					}
				}

				public int getRondas() {
					return rondas;
				}

				public void setRondas(int rondas) {
					this.rondas = rondas;
				}

				public int getMinimo() {
					return minimo;
				}

				public void setMinimo(int minimo) {
					this.minimo = minimo;
				}
			
				public static void main(String[] args) {
					DadoCargado d1 = new DadoCargado(12,10);
					Dado d2 = new Dado(6);
					Dado d3 = new Dado(16);
					Dado[] dados = new Dado[3];
					dados[0]=d1;
					dados[1]=d2;
					dados[2]=d3;
					Cubilete vaso = new Cubilete(dados);
					Jugador j1 = new Jugador("Natalia2");
					Jugador j2 = new Jugador("Tomas2");
					Juego4 jj = new Juego4(vaso,j1,j2);
					jj.setRondas(1500);
					jj.setMinimo(1);
					//jj.jugar();
					
					
					Jugador bueno = new Jugador("Bueno");
					JugadorTramposo tramposo = new JugadorTramposo("Tramposo");
					Cubilete ccc1 = new Cubilete();
					Juego4 jj2 = new Juego4(ccc1,bueno, tramposo);
					jj2.jugar();
					
					
				}	
			
}
