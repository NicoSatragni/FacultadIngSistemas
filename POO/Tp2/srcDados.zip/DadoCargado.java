
public class DadoCargado extends Dado {

	int ladoCargado;
	double probTrampa;
	
	public DadoCargado(int caras,int lado) {
		super(caras);
		ladoCargado= lado;
		probTrampa = 0.5;
	}
	public int tirar() {
		if (Math.random()>probTrampa) {
			return ladoCargado;
		} else {
			return super.tirar();
		}
		
		
	}
}
