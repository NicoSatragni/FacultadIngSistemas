
public class Dado {
	private int cantCaras;
	private int ultimoValor;

	public int getCantCaras() {
		return cantCaras;
	}
	public int getUltimoValor() {
		return ultimoValor;
	}
	
	public int tirar() {
		ultimoValor = (int) (Math.random()*getCantCaras() +1);
	    return ultimoValor;
	}
	
	
	public Dado() {
		this(6);
	}
	public Dado(int caras) {
		cantCaras=caras;
		this.tirar();
	}
	
	
}
