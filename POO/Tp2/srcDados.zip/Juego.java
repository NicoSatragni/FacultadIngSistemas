
public class Juego {

	private int puntos1;
	private int puntos2;

	public void jugar() {
		int tirada1, tirada2;
		for (int i =0 ; i<10; i++) {
			tirada1 = tirarDado() + tirarDado();
			tirada2 = tirarDado() + tirarDado();
			if (tirada1>tirada2 && tirada1>=7) {
				puntos1++;
			} else {
				if (tirada2>tirada1 && tirada2>=7) {
					puntos2++;
				}
			}
		}
		String ganador = ganador();
	    if (ganador!= null) {
	    	System.out.println("Gano el " + ganador);
	    } else {
	    	System.out.println("Empate");
	    }
				
	}

	
	
	
	public String ganador() {
		if (puntos1>puntos2) {
			return "Jugador 1";
		} else {
			if (puntos2>puntos1) {
                return "Jugador 2";   
			}	
			else {
				return null; 
			}
		}
	}
	
	public int tirarDado() {
		return (int) (Math.random()*6 +1);
	}
	
	
	
	public Juego() {
		puntos1=0;
		puntos2=0;
	}
	
	public static void main(String[] args) {
		Juego jj = new Juego();
		jj.jugar();
	}
}
