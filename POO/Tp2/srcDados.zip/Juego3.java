
public class Juego3 {
			private Jugador j1;
			private Jugador j2;
			private Dado d1;
			private Dado d2;
			
			private int rondas;
			private int minimo;
			
			public Juego3() {
			 	this(new Dado(), new Dado());
			}
			
			public Juego3(Dado d1, Dado d2) {
				this( d1,d2, new Jugador("El Jugador 1") ,
						new Jugador("El Jugador 2"));
			}
			
			public Juego3(Dado d1, Dado d2, Jugador j1, Jugador j2) {
				this.j1 = j1;
				this.j2 = j2;
				this.d1 = d1;
				this.d2 = d2;
				rondas = 10;
				minimo = 7;
			}
			public void jugar() {
				int tirada1, tirada2;
				for (int i =0 ; i<rondas; i++) {
					System.out.println("-- RONDA " + i);
					tirada1 = j1.tirarDados(d1, d2);
					tirada2 = j2.tirarDados(d1, d2);
					
					if (tirada1>tirada2 && tirada1>=minimo) {
						j1.sumarPunto();
					} else {
						if (tirada2>tirada1 && tirada2>=minimo) {
							j2.sumarPunto();
						}
							
					}
				}
				
				Jugador jj = this.getGanador();
				
				if (jj != null) {
					System.out.println("Gano : " + jj.getNombre());
				} else {
					System.out.println("Empate");
						
				}
				
					System.out.println("Jugador 1:" + j1.getPuntos());
					System.out.println("Jugador 2:" + j2.getPuntos());
				
				
			}
			
			public Jugador getGanador() {
				if (j1.getPuntos()>j2.getPuntos()) {
					return j1;
				} else {
					if (j2.getPuntos()>j1.getPuntos()) {
						return j2;
					} else {
						return null;
					}
				}
			}

			public int getRondas() {
				return rondas;
			}

			public void setRondas(int rondas) {
				this.rondas = rondas;
			}

			public int getMinimo() {
				return minimo;
			}

			public void setMinimo(int minimo) {
				this.minimo = minimo;
			}
			
			public static void main(String[] args) {
				Jugador j1 = new Jugador("Natalia");
				Jugador j2 = new Jugador("Tomas");
				Dado da = new Dado(3);
				Dado db = new Dado(3);
				Juego3 jj = new Juego3(da, db, j1, j2);
				jj.setRondas(350);
				jj.jugar();
			}
		
}
