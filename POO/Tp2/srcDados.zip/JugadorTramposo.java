
public class JugadorTramposo extends Jugador {

	Dado[] dadosCargados;
	public JugadorTramposo(String nn) {
		super(nn);
		dadosCargados = new Dado[2];
		dadosCargados [0] = new DadoCargado(6,6);
		dadosCargados [1] = new DadoCargado(6,6);
	}
	
	public int tirarDados(Cubilete vasito ) {
		
		Dado[] dados = vasito.getDados();
		vasito.setDados(dadosCargados);
		int valor = vasito.tirar();
		vasito.setDados(dados);
		return valor;
	}
	
	
}
