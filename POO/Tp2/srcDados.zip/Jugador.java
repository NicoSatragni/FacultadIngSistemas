
public class Jugador {

	private String nombre;
	private int puntos;
	
	public Jugador(String ss) {
		nombre = ss;
		puntos = 0;
	}
	public String getNombre() {
		return nombre;
	}
	public void setNombre(String nombre) {
		this.nombre = nombre;
	}
	public int getPuntos() {
		return puntos;
	}
	public void sumarPunto() {
		puntos ++;
	}

	
	
	public int tirarDados(Dado dadito1, Dado dadito2 ) {
		int valor= dadito1.tirar()+dadito2.tirar();
		System.out.println(" yo " + nombre + " tire :" + valor);
		
		return valor;
	}
	
	public int tirarDados(Cubilete vasito ) {
		int valor= vasito.tirar();
		System.out.println(" yo " + nombre + " tire :" + valor);
		return valor;
	}
	
}
